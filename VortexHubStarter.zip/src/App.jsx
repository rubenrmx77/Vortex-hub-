
export default function App() {
  return (
    <div style={{padding:"2rem"}}>
      <h1>Vortex Hub</h1>
      <p>Catálogo de servicios digitales.</p>
    </div>
  );
}
