# Vortex Hub Starter

Proyecto inicial para catálogo de servicios digitales.
Tecnologías sugeridas: React + Vite + Tailwind + Supabase.
